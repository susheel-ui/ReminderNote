package com.example.assignment2_remendernotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.assignment2_remendernotes.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(MainActivity.this,binding.btnMore);
                popupMenu.getMenuInflater().inflate(R.menu.menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int id = item.getItemId();
                        if(id==R.id.viewRemender){
                            Intent in = new Intent(MainActivity.this,ViewRemenderActivity.class);
                            startActivity(in);
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
       binding.btnSave.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String title = binding.EtTitle.getText().toString();
               String note = binding.EtNote.getText().toString();
//               Log.e("log cheked",title+" "+note);
               if(!title.equals("")&& !note.equals("")){
                   dbHandler dbHandler = new dbHandler(MainActivity.this);
                   SQLiteDatabase db = dbHandler.getWritableDatabase();
                   String query = "INSERT INTO remindertable (Title,Note)\n" +
                           "VALUES ('"+title+"','"+note+"' );";

                   db.execSQL(query);
                   db.close();
                   clearField();
               }
               else{
                   Toast.makeText(MainActivity.this, "pls enter value fields", Toast.LENGTH_SHORT).show();
               }


           }
       });
       binding.btnReset.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               clearField();
           }
       });






    }
    public void clearField(){
        binding.EtNote.setText("");
        binding.EtTitle.setText("");
    }
}