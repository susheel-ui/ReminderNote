package com.example.assignment2_remendernotes;

import java.io.Serializable;

public class Reminder implements Serializable {
    int id;
    String title;
    String note;
    Reminder(){

    }


    public Reminder(int id, String title, String note) {
        this.id = id;
        this.title = title;
        this.note = note;
    }

}
