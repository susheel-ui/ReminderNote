package com.example.assignment2_remendernotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.assignment2_remendernotes.databinding.ActivityUpdateLayoutBinding;

public class UpdateLayout extends AppCompatActivity {
    ActivityUpdateLayoutBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateLayoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dbHandler dbhandler = new dbHandler(UpdateLayout.this);
        Intent in = getIntent();
        int Sno = Integer.parseInt(in.getStringExtra("Sno"));
        Log.e("Sno ->","Sno is "+Sno);
        SQLiteDatabase db = dbhandler.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from remindertable where Sno="+Sno,null);
        cursor.moveToNext();

        binding.editTextTextPersonName.setText(cursor.getString(1));
        binding.Note.setText(cursor.getString(2));
        db.close();


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Title = binding.editTextTextPersonName.getText().toString();
                String note = binding.Note.getText().toString();

                SQLiteDatabase db = dbhandler.getWritableDatabase();
                db.execSQL("update remindertable set Title='"+Title+"',Note='"+note+"' where Sno="+Sno);
                db.close();
                finish();
            }
        });
        binding.btnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



    }
}