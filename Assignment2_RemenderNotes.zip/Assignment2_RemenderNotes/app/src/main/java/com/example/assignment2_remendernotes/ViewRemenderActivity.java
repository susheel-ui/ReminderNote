package com.example.assignment2_remendernotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.assignment2_remendernotes.databinding.ActivityViewRemenderBinding;
import com.example.assignment2_remendernotes.databinding.ListShowBinding;

import java.util.ArrayList;

public class ViewRemenderActivity extends AppCompatActivity {
    ActivityViewRemenderBinding binding;
    ListShowBinding binding1;
    Myadapter adapter;
    ArrayList<Reminder> listReminder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewRemenderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        listReminder = new ArrayList<Reminder>();


    }

    @Override
    protected void onStart() {

        super.onStart();
        dbHandler dbHandler = new dbHandler(ViewRemenderActivity.this);
        SQLiteDatabase db = dbHandler.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from remindertable", null);

        listReminder.clear();
        for (int i = 0; i < cursor.getCount(); i++) {
            cursor.moveToNext();
            listReminder.add(new Reminder(cursor.getInt(0), cursor.getString(1), cursor.getString(2)));
            Log.e("Reminders :-", cursor.getInt(0) + cursor.getString(1) + cursor.getString(2));

        }
         adapter = new Myadapter(ViewRemenderActivity.this,listReminder);
        binding.notesShow.setAdapter(adapter);



    }

    class Myadapter extends ArrayAdapter {
//

        ArrayList<Reminder> list;
        Context context;

        public Myadapter(@NonNull Context context, ArrayList<Reminder> resource) {
            super(context, R.layout.list_show, resource);


            this.context = context;
            list = resource;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Reminder rem = list.get(position);
            binding1 = ListShowBinding.inflate(getLayoutInflater());

           binding1.Title.setText(rem.title);
           binding1.noteField.setText(rem.note);
           binding1.btnDelete.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   listReminder.remove(position);
                   dbHandler dbhandler = new dbHandler(ViewRemenderActivity.this);
                   SQLiteDatabase db = dbhandler.getWritableDatabase();
                   db.execSQL("Delete from remindertable where Sno ="+rem.id);
                   Toast.makeText(ViewRemenderActivity.this, ""+rem.title+" Deleted", Toast.LENGTH_SHORT).show();
                   db.close();
                    adapter.notifyDataSetChanged();
               }
           });
           binding1.btnUpdate.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   Intent in = new Intent(ViewRemenderActivity.this,UpdateLayout.class);
                   in.putExtra("Sno",""+rem.id);
                   startActivity(in);
               }
           });

            return binding1.getRoot();
        }
    }
}
