package com.example.assignment2_remendernotes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHandler extends SQLiteOpenHelper {

    public dbHandler(@Nullable Context context) {
        super(context, "Reminder.sqlite", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table remindertable(Sno Integer PRIMARY KEY AUTOINCREMENT,Title text,Note text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
